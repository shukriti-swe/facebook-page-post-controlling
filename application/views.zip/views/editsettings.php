<!DOCTYPE html>
<html lang="en">
<head>
  <title>fbpost</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>


<div class="container mt-5">
  <div class="row">
    <div class="col-md-8 offset-md-2">
      <h1 style="text-align:center;text-decoration:underline;"> Overview</h1>
       
        <p class="mb-0"><b>Total Process : <?php echo $alldata; ?></b></p>
        <p class="mb-0"><b>process complete : <?php echo $process; ?></b></p>
        <p class="mb-0"><b>Process remaining : <?php echo ($alldata - $process) ; ?></b></p>
        <div style="display: flex;"> <b>status</b> : <?php 
        if($setting->status==1){
          echo " <p style='color:green;'><b> Running</b></p>";
        }elseif($setting->status==0){
          echo " <p style='color:red;'><b> Stopped</b></p>";
        }elseif($setting->status==3){
           echo " <p style='color:gray;'><b> Delete</b></p>";
        }
        
        ?></div>
       

        
        <form action="<?php echo base_url(); ?>edit-settings/<?php echo $setting->id; ?>" method="post">
        <div class="mb-3">
            <label for="project_name" class="form-label">Project Name</label>
            <input type="text" class="form-control" value="<?php echo $setting->project_name; ?>" id="project_name" name="project_name">
        </div>
        <div class="mb-3">
            <label for="fb_user_access_token" class="form-label">FB user access token</label>
            <input type="text" class="form-control" value="<?php echo $setting->fb_user_access_token; ?>" id="fb_user_access_token" name="fb_user_access_token">
        </div>
        <div class="mb-3">
            <label for="app_id" class="form-label">App id</label>
            <input type="text" class="form-control" value="<?php echo $setting->app_id; ?>" id="app_id" name="app_id">
        </div>
        <div class="mb-3">
            <label for="app_secret" class="form-label">App secret</label>
            <input type="text" class="form-control" value="<?php echo $setting->app_secret; ?>" id="app_secret" name="app_secret">
        </div>

        <div class="mb-3">
          <label for="app_secret" class="form-label">status</label>
          <select class="form-control"  name="status" id="status">
            <option value="1" <?php if($setting->status==1){echo "selected";} ?>>Running</option>
            <option value="0" <?php if($setting->status==0){echo "selected";} ?>>Stop</option>
            <option value="3" <?php if($setting->status==3){echo "selected";} ?>>Delete</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="app_secret" class="form-label">Frequency</label>
          <select class="form-control" name="frequency" id="frequency">
            <option value="2" <?php echo ($setting->frequency == 2 ? 'selected':''); ?>>2</option>
            <option value="3" <?php echo ($setting->frequency == 3 ? 'selected':''); ?>>3</option>
            <option value="4" <?php echo ($setting->frequency == 4 ? 'selected':''); ?>>4</option>
            <option value="5" <?php echo ($setting->frequency == 5 ? 'selected':''); ?>>5</option>
            <option value="6" <?php echo ($setting->frequency == 6 ? 'selected':''); ?>>6</option>
            <option value="7" <?php echo ($setting->frequency == 7 ? 'selected':''); ?>>7</option>
            <option value="8" <?php echo ($setting->frequency == 8 ? 'selected':''); ?>>8</option>
            <option value="9" <?php echo ($setting->frequency == 9 ? 'selected':''); ?>>9</option>
            <option value="10" <?php echo ($setting->frequency == 10 ? 'selected':''); ?>>10</option>
          </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
    </div>
  </div>
    
  
</div>

</body>
</html>
