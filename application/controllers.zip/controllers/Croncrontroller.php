<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Croncrontroller extends CI_Controller {

	public function __construct()
	{
	    // Call the CI_Model constructor
	    parent::__construct();
	    $this->load->model('Urllists');
	}

    public function getFBpost(){
      // echo date_default_timezone_get();die();


        $getAllProject = $this->Urllists->getAllproject();
       // echo $this->db->last_query();die();
  
        
        foreach($getAllProject as $project){

            //$renew_time = $project->renew_time;
            //$minutes_to_add = $project->frequency*60;
           // $time = new DateTime($renew_time);
            //$time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
            //$pre_time = $time->format('Y-m-d H:i:s');
            //$pre_time ="2023-01-22 02:15:43";
           // $now_time = date('d-m-y h:i:s');

           // if($pre_time<$now_time){

            $userId = $this->getUserID($project->id);
            
            //$page_access_key = $this->getAllPages($userId);
            $settings =  $this->Urllists->getSettigns($project->id);
            $page_access_key = $settings->fb_page_access_token;
            $siteUrl = $this->Urllists->getSingleSite($project->id);
            if(empty($siteUrl)){
                $upload_file = $this->Urllists->againXmlUpload($project->xml_file_name,$project->id);
                $siteUrl = $this->Urllists->getSingleSite($project->id);
            }
            
      
            
            //echo "<pre>";print_r($siteUrl);die();
            foreach( $siteUrl as $url){
            $myfbpost = $this->postToFB($url, $page_access_key,$project->id);
            }
          //  }

        }
      

       
    }


public function getUserID($project_id){
        $settings =  $this->Urllists->getSettigns($project_id);
        $ch = curl_init();
        $url = "https://graph.facebook.com/v12.0/me?fields=id,name&access_token=".$settings->long_fb_user_access_token;

        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        
         $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close ($ch);
        $data = json_decode($result, true);
        $userId =  $data['id']; 
        return $userId;  
}


// public function getAllPages($userId){

//     $settings =  $this->Urllists->getSettigns();
//     $ch = curl_init();
//     $url = "https://graph.facebook.com/".$userId."/accounts?fields=name,access_token&access_token=".$settings->fb_user_access_token;

//     curl_setopt($ch, CURLOPT_URL, $url);
//     curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    
//     $result = curl_exec($ch);
//     if (curl_errno($ch)) {
//         echo 'Error:' . curl_error($ch);
//     }
//     curl_close ($ch);
//     //echo $result;
//     $pages = json_decode($result, true);
//     return $page_access_key = $pages['data'][1]['access_token'];
// }

public function postToFB($dataurl, $page_access_key,$project_id){
    $settings =  $this->Urllists->getSettigns($project_id);
    $ch = curl_init();

    $url = "https://graph.facebook.com/v12.0/".$settings->fb_page_id."/feed";

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS,
                "link=".urlencode($dataurl)."&access_token=".$page_access_key);
    
   echo $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close ($ch);
    $fb_id = json_decode($result);

    $data = [
    'fb_id'=> $fb_id->id,
    'status'=>1
    ];
    $siteUrl = $this->Urllists->updateData('urllists',$data,'url',$dataurl,$project_id);
    
    $this->Urllists->project_time($project_id );
   
   // echo $project_id;die();
    echo $result;
}

            


}